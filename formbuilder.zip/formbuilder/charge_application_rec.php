<?php
require 'application/shopify.php';
DEFINE('SHOPIFY_API_KEY','2757270060e4507e59343f97bf06e003');
DEFINE('SHOPIFY_SECRET','e58a7f29f20a762569a0546caec8f4f1');
$dsn = "pgsql:"
    . "host=ec2-23-21-204-166.compute-1.amazonaws.com;"
    . "dbname=d26b121vet4u2e;"
    . "user=raathrrrqrzdcx;"
    . "port=5432;"
    . "password=ba861663d4ce227b14954d08d790c0ec5a1e1af035ae0aca380e752b5570cdce";
    $db = new PDO($dsn);

$chargeId = $_GET['charge_id'];
if($chargeId == '')
{

}
else
{
$query_params['shop'] = $_GET['shop'];
$select_store_data = $db->query("SELECT * FROM app_data_tbl WHERE shop_address = '".$query_params['shop']."'");
$shop_details = $select_store_data->fetch(PDO::FETCH_ASSOC);
$shop_id=$shop_details['shop_id'];
$shop_name=$shop_details['shop_address'];
$shop_token=$shop_details['shop_token'];
$confirmation_url=$shop_details['confirm_url'];
$sc = new ShopifyClient($shop_name, $shop_token, SHOPIFY_API_KEY, SHOPIFY_SECRET);
if($shop_details)
{
$received = $sc->call('GET', "/admin/recurring_application_charges/{$chargeId}.json");
$value = $received['status'];
$charge_stat = $sc->call('GET', "/admin/recurring_application_charges/{$chargeId}.json");
if ($charge_stat['status'] == "accepted") {
$billing_on = date("Y-m-d") . "T00:00:00+00:00";
$create_at = date("Y-m-d\TH:i:s") . "+05:30";
$updated_at = date("Y-m-d\TH:i:s") . "+05:30";
$trial_ends_on = date("Y-m-d\TH:i:s", strtotime("+7 days")) . "+05:30";
$act_recurring_charge_arr = array("recurring_application_charge" =>
array("activated_on" => null,
"billing_on" => $billing_on,
"cancelled_on" => null,
"created_at" => $create_at,
"id" => $chargeId,
"name" => "Basic Plan", 
"price" => 55.00,
"return_url" => 'https://wholesalerevm.herokuapp.com/',
"status" => "accepted",
"test" => false,
"trial_days" => 7,
"trial_ends_on" => $trial_ends_on,
"updated_at" => $updated_at
));
try {
$act_recurring_charge_call = $sc->call('POST', "/admin/recurring_application_charges/{$chargeId}/activate.json", $act_recurring_charge_arr);
$update= $db->query("UPDATE  app_data_tbl SET charge_status =  '$value' WHERE  shop_address =  '$shop_name'");
echo "<script>parent.location.href='https://wholesalerevm.herokuapp.com/'</script>";
} catch (Exception $e) {

}
} else {
echo "<script>parent.location.href='$confirmation_url'</script>";
}
}
}
?>