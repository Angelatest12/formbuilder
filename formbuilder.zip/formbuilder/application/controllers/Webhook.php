<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Webhook extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
    	$this->load->database();
		$this->load->model('Admin_model');
		
		$this->load->file("application/shopify.php", true);			
	}
	//Index function starts here app Installation
	public function index()
		{

			$to = 'vinita@expertvillagemedia.com'; // this is your Email address
							$from = "support@expertvillagemedia.com"; // this is the sender's Email address
							$subject = "Thank you for uninstalling our Wholesale App!";
							$message = "<p>Hello,</p>
							    <br/>

							<p>Thank you very much for uninstalling our App!</p>

							<p>If you have any Issues or Questions please let us know by replying to this email and We will respond to you asap.

							Hope you enjoy using our app!</p>

							<p>Kind regards,</p>
							<p>Expert Village Media</p>";

							$url = 'https://api.sendgrid.com/';
							$user = 'app65982267@heroku.com';
							$pass = 'test111G';
							$params = array( 
							      'api_user' => $user,
							      'api_key' => $pass,
							      'to' => $to,
							      'subject' => $subject,
							      'html' => $message,
							      'text' => $message,
							      'from' => $from,
							   );
							 $request = $url.'api/mail.send.json';
							 $session = curl_init($request);
							 curl_setopt ($session, CURLOPT_POST, true);
							 curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
							 curl_setopt($session, CURLOPT_HEADER, false);
							 curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
							 $response = curl_exec($session);
							 print_r($response);
							 curl_close($session);
							 die;
			$shop = $_GET['shop'];
			if(!empty($shop))
			{
				$this->Admin_model->delete('shop_address',$shop,'app_data_tbl');
			}			
		}
	//Index function ends here


}
