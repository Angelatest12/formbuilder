<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Formbuilder extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
    	$this->load->database();
		$this->load->model('Admin_model');
		$this->load->library(array('session'));
		$this->load->helper('url');
		$this->load->file("application/shopify.php", true);
	}
	//Index function starts here app Installation
	public function index()
		{
			if ($this->input->get('code')!=null) 
			{ 				
				// if the code param has been sent to this page... we are in Step 2
				// Step 2: do a form POST to get the access token
				$shop = $this->input->get('shop');
				$shopifyClient = new ShopifyClient($shop, "", SHOPIFY_API_KEY, SHOPIFY_SECRET);
				$create_date=date('Y-m-d');
				// Now, request the token and store it in your session.
				$shop_token = $shopifyClient->getAccessToken($this->input->get('code'));
				$sc = new ShopifyClient($shop, $shop_token, SHOPIFY_API_KEY, SHOPIFY_SECRET);
				$shop_details = $sc->call('GET', '/admin/shop.json');
				
				if($shop!=null)
				{
					$where = array('shop_address'=>$shop);	    
	    			$shop_record=$this->Admin_model->get_row_where('app_data_tbl',$where);
	    			$shop_address= "";
	    			if(!empty($shop_record->shop_address))
					$shop_address=$shop_record->shop_address;
					if($shop_address == $shop)
					{
						echo "Application Installed. Redirecting...";   
						echo "<script>parent.location.href='https://$shop/admin/apps/form-builder-by-evm'</script>";
							exit;                 
						?>
						<a href="https://<?php echo $shop;?>/admin/apps/">Click here</a>;
						<?php
						die;
					}
					else
					{
						$shop_details = $sc->call('GET', '/admin/shop.json');
						$shop_email= $shop_details['email'];
						$shop_owner= $shop_details['shop_owner'];
						$shop_data = array('shop_token' =>$shop_token,'shop_address'=>$shop,
				    	'create_date'=>$create_date,'shop_owner'=>$shop_owner,'shop_email'=>$shop_email);
				    	//print_r($shop_data);
				    	$insertSData=$this->Admin_model->insert_update_data(
		    			$shop_data,'app_data_tbl');	
		    				    			
						if($insertSData== 0)
						{                    
							echo "Installation Failed....!!!";
						}
						else
						{
							// confirmation mail code
							$to = $shop_email; // this is your Email address
							//$to = "vinita@expertvillagemedia.com";
							$from = "support@expertvillagemedia.com"; // this is the sender's Email address
							$subject = "Thank you for installing our Form Builder App!";
							$message = "<p>Hello,</p>

							<p>Thank you very much for installing our Formbuilder App!</p>

							<p>If you have any Issues or Questions please let us know by replying to this email and We will respond to you asap.

							Hope you enjoy using our app!</p>

							<p>Kind regards,</p>
							<p>Expert Village Media</p>";

							$url = 'https://api.sendgrid.com/';
							$user = 'app65982267@heroku.com';
							$pass = 'test111G';
							$params = array( 
							      'api_user' => $user,
							      'api_key' => $pass,
							      'to' => $to,
							      'subject' => $subject,
							      'html' => $message,
							      'text' => $message,
							      'from' => $from,
							   );
							 $request = $url.'api/mail.send.json';
							 $session = curl_init($request);
							 curl_setopt ($session, CURLOPT_POST, true);
							 curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
							 curl_setopt($session, CURLOPT_HEADER, false);
							 curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
							 $response = curl_exec($session);
							 
							 curl_close($session);
							// confirmation mail code end here

						   // =======add code for uninstall app =======  
						   $ch = curl_init("https://$shop/admin/webhooks.json");
						   $callback = 'https://formbuilderbyevm.herokuapp.com/uninstall.php?shop='.$shop;
						   $postwebhook = array("webhook" => array( "topic"=>"app/uninstalled",
							"address"=> $callback,
							"format"=> "json"));

							$webhook = str_replace('\\/', '/', json_encode($postwebhook));
							curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
							curl_setopt($ch, CURLOPT_POSTFIELDS, $webhook);
							curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "X-Shopify-Access-Token: $shop_token")); 
							echo '<div style="display:none;">'.curl_exec($ch).'</div>' ;

							echo "<script>parent.location.href='https://$shop/admin/apps/form-builder-by-evm'</script>";
							exit;                              
						}
					}
				}    
			}
			else
			{				
				if($this->input->get('shop')!=null) 
				{

					$hmac=$this->input->get('hmac');
					$timestamp=$this->input->get('timestamp');
					// Step 1: get the shopname from the user and redirect the user to the
					// shopify authorization page where they can choose to authorize this app
					$shop = $this->input->get('shop');
					$where = array('shop_address'=>$shop);	    
	    			$shop_record=$this->Admin_model->get_row_where('app_data_tbl',$where);
	    			$shop_address= "";
	    			if(!empty($shop_record->shop_address))
					$shop_address=$shop_record->shop_address;

						if($shop_address == $shop)
						{

							$shopifyClient = new ShopifyClient($shop, "", SHOPIFY_API_KEY, SHOPIFY_SECRET);
							$shop_token = $shop_record->shop_token;

							$sc = new ShopifyClient($shop, $shop_token, SHOPIFY_API_KEY, SHOPIFY_SECRET);
							$shop_webhooks = $sc->call('GET', '/admin/webhooks.json');
							
							$headerdata = array('active'=>'dashboard','shop'=>$shop,'title'=>'Dashboard');
							$data = array('shop'=>$shop);
							$where = array('shop_name'=>$shop); 							    
	    					$all_forms=$this->Admin_model->get_all_where('form_setting',$where);
	    					$data['all_forms']= $all_forms;
							$this->load->view('header',$headerdata);							
							if(!empty($all_forms[0]->id))
							{$this->load->view('dashboard',$data);}
							else
							{$this->load->view('createform',$data);}
							$this->load->view('footer',$headerdata);   
						}
						else
						{
							$shopifyClient = new ShopifyClient($shop, "", SHOPIFY_API_KEY, SHOPIFY_SECRET);
							// get the URL to the current page
							$pageURL = 'https';
								if ($_SERVER["HTTPS"] == "on") { $pageURL .= "s"; }
							$pageURL .= "://";
								if ($_SERVER["SERVER_PORT"] != "80") {
								$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"];
								} else {
								$pageURL .= $_SERVER["SERVER_NAME"];
								}            
							// redirect to authorize url
							//echo $shopifyClient->getAuthorizeUrl(SHOPIFY_SCOPE, $pageURL);die;
							header("Location: " . $shopifyClient->getAuthorizeUrl(SHOPIFY_SCOPE, $pageURL));
							exit;
						}
				}
			}	  
		
	}	
	//Index function ends here

	

	public function embed($shop,$id)
	{
		if(!empty($shop))
		{
			$headerdata = array('active'=>'dashboard','shop'=>$shop,'title'=>'Embed code');			
	    	$data = array('shop'=>$shop,'form_id'=>$id);
			$this->load->view('header',$headerdata);
			$this->load->view('embed',$data);
			$this->load->view('footer');
		}				
	}	

	public function create_form($shop)
	{
		if(!empty($shop))
		{
			$headerdata = array('active'=>'dashboard','shop'=>$shop,'title'=>'Create Form');			
	    	$data = array('shop'=>$shop);
			$this->load->view('header',$headerdata);
			$this->load->view('createform',$data);
			$this->load->view('footer');
		}
				
	}

	public function view_form($shop,$id)
	{
		if(!empty($shop))
		{			
			//$shop = $this->input->get('shop');
			//$id = $this->input->get('id');
			$headerdata = array('active'=>'dashboard','shop'=>$shop,'title'=>'View Form');			
			$where = array('id'=>$id);	    
	    	$form_record=$this->Admin_model->get_row_where('form_setting',$where);
	    	$form_title = $form_record->form_title;
	    	$data = array('shop'=>$shop,'id'=>$id,'form_title'=>$form_title);
			$this->load->view('header',$headerdata);
			$this->load->view('view_form',$data);
			$this->load->view('footer');
		}
	}

	public function load_form()
	{
		$form_id = $_GET['form_id'];
		$where = array('id'=>$form_id);	    
	    $form_record=$this->Admin_model->get_row_where('form_setting',$where);
	    			
	    if(!empty($form_record->form_fields))
	    	echo $form_record->form_fields;
	    die;		
	}

	public function load_form_front()
	{
		$callback ='evmcallback'; 
	    if(isset($_GET['evmcallback']))
	    {
	        $callback = $_GET['evmcallback'];
	    }
		$form_id = $_GET['form_id'];
		$where = array('id'=>$form_id);	    
	    $form_record=$this->Admin_model->get_row_where('form_setting',$where);
	    			
	    if(!empty($form_record->form_fields))    	

	    $arr =array('form_title'=>$form_record->form_title,'form_data'=>json_decode($form_record->form_fields));
	    echo $callback.'(' . json_encode($arr) . ')';
	    exit;		
	}



	public function edit_form($shop,$form_id)
	{		
		$where = array('id'=>$form_id);	    
	    $form_record=$this->Admin_model->get_row_where('form_setting',$where);
	    $headerdata = array('active'=>'dashboard','shop'=>$shop,'title'=>'Edit Form');			
	    if(!empty($form_record->form_fields))
	    	$data = array('form_fields'=>$form_record->form_fields,'form_id'=>$form_id,'form_title'=>$form_record->form_title);
	    	$this->load->view('header',$headerdata);
			$this->load->view('edit_form',$data);
			$this->load->view('footer');	    
	}

	public function form_save()
	{	
		$form_data = json_decode(file_get_contents('php://input'));
			foreach ($form_data as $key => $value) {
			    $field[$value->name] = $value->value;
			}
			$form_id    = $field['form_id'];
			$form_title = $field['form_title'];
			$shop_name = $field['shop_name'];
			$formFields = json_encode($field['formFields']);
			if($form_id)
			{
				$shop_data = array('form_title'=>$form_title,'form_fields'=>$formFields);

				$this->Admin_model->insert_update_data($shop_data,'form_setting','id',$form_id);
				$insertSData= $form_id;
			}
			else
			{
				$shop_data = array('shop_name' =>$shop_name,'create_date'=>date('Y-m-d'),'form_title'=>$form_title,'form_fields'=>$formFields);
					    	//print_r($shop_data);
		    	$insertSData=$this->Admin_model->insert_update_data(
				$shop_data,'form_setting');	
		    }

			if($insertSData)
			{
				$returndata = array('shop'=>$shop_name,'id'=>$insertSData);
				//print_r($returndata);
				echo json_encode($returndata);
		 	}
			else
			{
				echo "error";
			}
			die;
		}

	public function delete()
	{
		$ID = $this->input->post('ID');
		$shop_address = $this->input->post('shop_address');
		$id = base64_decode($ID);		

		$delete=$this->Admin_model->delete('id',$id,'form_setting');
		if($delete==1)
		{			
			echo '1';
			exit;
		}
		echo 0;
		exit;
	}


	public function deleteAll()
	{
		$chk = $this->input->post('chk');
		$shop_address = $this->input->post('shop_name');		
		if($chk)
		{
			foreach($chk as $key=>$val)
			{
				
				$delete=$this->Admin_model->delete('id',$val,'form_setting');
			}
		}
		$this->session->set_flashdata('message', 'Form deleted successfully.');
		redirect("Formbuilder?shop=".$shop_address);
	}
}
