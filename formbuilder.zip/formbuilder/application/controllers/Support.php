<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Support extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
    	$this->load->database();
		$this->load->model('Admin_model');
		$this->load->library(array('session'));
		$this->load->helper('url');
		$this->load->file("application/shopify.php", true);
			
	}

	public function index()
	{
		$shop = $this->input->get('shop');
		$headerdata = array('active'=>'support','shop'=>$shop,'title'=>'Support');	
		$where = array('shop_address'=>$shop);		
		$shop_record=$this->Admin_model->get_row_where('app_data_tbl',$where);
		$shop_address= $shop_token="";
		$data = array();
		if(!empty($shop_record->shop_address))
		{
			$shop_name=$shop_record->shop_address;
			$shop_token=$shop_record->shop_token;
			$shop_owner = $shop_record->shop_owner;
			$shop_email = $shop_record->shop_email;
		}
		if(isset($_POST['btn-save']))
		{
			$msg="";

			$to = "support@expertvillagemedia.com"; 
			//$to = "vinita@expertvillagemedia.com"; 
			$from = $shop_email; 
			
			$subject = "Form builder App Support Request From $shop_owner!";
			$message = "Hello,

			This is $shop_owner.<br/>
			My Store URL is $shop_name.
			";
			$message = $message."<br/>".$_POST['query'];

			$url = 'https://api.sendgrid.com/';
			$user = 'app65982267@heroku.com';
			$pass = 'test111G';
			$params = array( 
			'api_user' => $user,
			'api_key' => $pass,
			'to' => $to,
			'subject' => $subject,
			'html' => $message,
			'text' => $message,
			'from' => $from,
			);
			$request = $url.'api/mail.send.json';
			$session = curl_init($request);
			curl_setopt ($session, CURLOPT_POST, true);
			curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
			curl_setopt($session, CURLOPT_HEADER, false);
			curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($session);

			curl_close($session);
			$this->session->set_flashdata('message', 'We have received your query. Our technical support will be in touch soon.');	
			
		}
		$data=array('shop_owner'=>$shop_owner,'shop_email'=>$shop_email,'shop_name'=>$shop_name);							
		$this->load->view('header',$headerdata);
		$this->load->view('support',$data);
		$this->load->view('footer');
	}
}
