<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Embed extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
    	$this->load->database();
		$this->load->model('Admin_model');
		$this->load->library(array('session'));
		$this->load->helper('url');
		$this->load->file("application/shopify.php", true);	
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Methods: POST');
		header('Access-Control-Max-Age: 1000');  	
	}
	//Index function starts here app Installation
	public function index()
		{   
		}
	//Index function ends here

	public function load_form_front()
	{
		$callback ='evmcallback'; 
	    if(isset($_GET['evmcallback']))
	    {
	        $callback = $_GET['evmcallback'];
	    }
		$form_id = $_GET['form_id'];
		$where = array('id'=>$form_id);	    
	    $form_record=$this->Admin_model->get_row_where('form_setting',$where);
	    			
	    if(!empty($form_record->form_fields))    	

	    $arr =array('form_title'=>$form_record->form_title,'form_data'=>json_decode($form_record->form_fields));
	    echo $callback.'(' . json_encode($arr) . ')';
	    exit;		
	}

	public function submit_form_front()
	{
		$callback ='evmcallback'; 
	    if(isset($_GET['evmcallback']))
	    {
	        $callback = $_GET['evmcallback'];
	    }
	    if(isset($_GET['shop']))
	    {
	        $shop = $_GET['shop'];
	    }
	    
	    if(isset($_GET['formId']))
	    {
	        $formId = $_GET['formId'];
	    }

	    $where = array('shop_address'=>$shop);	    
	    $shop_record=$this->Admin_model->get_row_where('app_data_tbl',$where);
	    $shop_email=$shop_record->shop_email;

	    $form_id = $_GET['formId'];
		$where = array('id'=>$form_id);	    
	    $form_record=$this->Admin_model->get_row_where('form_setting',$where);
	    			
	   	$form_title = $form_record->form_title; 
		$i=0;
		//print_r($_GET);
		$msg = $email = $firstval =  "";
	    foreach($_GET as $key=>$val)
	    {
	    		    	
	    	if(strpos($key, 'email-') !== false)
	    	{
	    		$email = $val;
	    	}
	    	
	    	if(!empty($key) && $key != 'evmcallback' && $key != 'shop' && $key != 'formId' && $key != '_')
	    	{
		        $i++;
		        if($i%2!=0)
		        {
		        	if(!empty($val))
		           	$msg.=$val." => ";
		        }
		        else   
		        {
		        	if(is_array($val))
		        	{
		        		foreach($val as$k=>$v)
		        		{
		        			$msg.= $v."<br>";
		        		}		        		
		        	}
		        else
		        	{
		        		
		        		if($i==2)
					        {
					        	$firstval = $val;
					        }
		        		$msg.=$val."<br>";
		        	}	        
		        }
	    	}
	    }    

	    $to = $shop_email; // this is your Email address
		//$to = "vinita@expertvillagemedia.com";
		$from = $email ; // this is the sender's Email address
		if(empty($email))
		{
			$from = $firstval;
		}
		
		$subject = "Enquiry from ".$email." for ".$form_title;
		$message = "<p>Hello,</p>
		<p>Below is detail information from  $form_title </p>
		<p>$msg</p>
		";

		$url = 'https://api.sendgrid.com/';
		$user = 'app65982267@heroku.com';
		$pass = 'test111G';
		$params = array( 
		      'api_user' => $user,
		      'api_key' => $pass,
		      'to' => $to,
		      'subject' => $subject,
		      'html' => $message,
		      'text' => $message,
		      'from' => $from,
		   );
		 $request = $url.'api/mail.send.json';
		 $session = curl_init($request);
		 curl_setopt ($session, CURLOPT_POST, true);
		 curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
		 curl_setopt($session, CURLOPT_HEADER, false);
		 curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
		 $response = curl_exec($session);
		 
		 curl_close($session);	
		 $arr = array('msg'=>"Done");
		echo $callback.'(' . json_encode($arr) . ')';
	    exit;		
	}
}
