<?php
class Admin_model extends CI_Model 
{ 
/**
* Responsable for auto load the database
* @return void
*/
public function __construct()
{
    $this->load->database();
}
/*******************************alredy inbuild function********************************************/

  public function insert_update_data($data,$table,$table_id=NULL,$id=NULL)
    {
      if($id)
      {   
        $this->_update($id,$data,$table,$table_id);
        return $id;
      }
      else
      {
        $this->_insert($data, $table);
        return $lastinsertid =$this->db->insert_id();
      }
    }
  
  public function _insert($data, $table)
  {   
    $this->db->set($data);
    if($this->db->insert($table) !== FALSE)
    {
      return TRUE;
    }
    return FALSE;
  }
  
  protected function _update($id, $data, $table, $table_id)
  {
    $this->db->where($table_id, $id);
    if($this->db->update($table, $data) !== FALSE)
    {
      return TRUE;
    }
    return FALSE;
  }
  
  public function get_all($table,$data=false)
  {   
    $query = $this->db->get($table);
    if($query->num_rows() > 0) 
    {
      return $query->result();
    } 
    else 
    { 
      return FALSE;
    }
  }
  
  public function get_all_where($table,$where,$where_or='')
  {
    $this->db->where($where);
    if($where_or)
    {
      $this->db->or_where($where_or);
    }
    $this->db->order_by("id","desc");
    $query=$this->db->get($table);
    if($query->num_rows() > 0)
    {
      return $query->result();
    } 
    else 
    { 
      return FALSE;
    }
  }
  public function get_all_where_in($table,$where,$in)
  {  
    $this->db->where_in($where, $in);
    $query =  $this->db->get($table);
    if($query->num_rows() > 0) 
    {
      return $query->result();
    } 
    else 
    { 
      return FALSE;
    }
  }
// Get All Data
      
public function get_row_where($table,$where,$where_or='')
  {
    $this->db->where($where);
    if($where_or){
    $this->db->or_where($where_or);
    }
    $query = $this->db->get($table);
    if($query->num_rows() > 0) {
    return $query->row();
    } else { 
    return FALSE;
  }
}
  
  public function get_all_where_count($table='',$whereArray)
  {
    $query = $this->db->get_where($table,$whereArray);
    if($query->num_rows() > 0) {
      return $query->num_rows();
      } else { 
      return FALSE;
      }
  }
  function getWhere($table,$where)
  {

    $this->db->where($where);           
    $getdata = $this->db->get($table);
            
    $num = $getdata->num_rows();
    if($num> 0)
    { 
        $arr=$getdata->result();
        foreach ($arr as $rows)
        {
          $data[] = $rows;
        }
        $getdata->free_result();
        return $data;
    }else{ 
      return false;
    }
    
  }
  function update($table,$where,$data)
  {
    $this->db->where($where );
    $update = $this->db->update($table,$data);
    
    if($update)
    { 
      return TRUE;
    }
    else
    { 
      return FALSE;
    }
  }

 public function delete($column,$value,$table)
   {
      $this ->db-> where($column,$value);
      $this ->db-> delete($table);
      return 1;
   } 
}
?>