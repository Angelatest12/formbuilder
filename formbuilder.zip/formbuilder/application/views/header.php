<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Form builder by EVM </title>
	<link rel="stylesheet" href="<?php echo base_url().'css/style.css';?>">
    <!-- CSS -->
   

    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.1.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>

     
    <script src="<?php  echo base_url();?>js/jquery-2.1.4.min.js"></script> <!-- jQuery v1 should also work fine -->
    <script src="<?php  echo base_url();?>js/jquery-ui.min.js" type="text/javascript" ></script> <!-- for sortable -->

    <!-- SJFB JS -->
    <script src="<?php  echo base_url();?>js/sjfb-builder.js" type="text/javascript" ></script> <!-- form builder -->
    <script src="<?php  echo base_url();?>js/sjfb-html-generator.js" type="text/javascript" ></script> <!-- form generator -->
     <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">
 <link href="<?php  echo base_url();?>/application/views/font/form-builder-font.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
</head>


<div class="app-header">
  <div class="header">
 
    <div class="app-heading">
<ul>
           <li class="help"><a href="<?php echo base_url().'Formbuilder?shop='.$shop;?>"  <?php if($active=='formbuilder'){?> class="active"   <?php } ?>>Dashboard</a></li>
                    <li><a href="<?php echo base_url().'Support?shop='.$shop;?>" <?php if($active=='support'){?> class="active"   <?php } ?>>Support</a></li>
                 <li><a href="<?php echo base_url().'Installation?shop='.$shop;?>" <?php if($active=='installation'){?> class="active"   <?php } ?>>Installation Guide</a></li> 
</ul>
    </div>
  </div>
</div>


<body>