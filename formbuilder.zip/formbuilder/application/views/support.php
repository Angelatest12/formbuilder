<div class="big-wrapper">
<div class="big-wrapper-container">
<div class="container">
<div class="evmmaindiv"><div class="left"><h3 class="evmheading">Support</h3></div>

<div id="msg">
   <?php if($this->session->flashdata('message')){?>
  <div class="alert alert-success">      
    <?php echo $this->session->flashdata('message')?><a href="#" class="close" onclick="clickme();" data-dismiss="alert" style="float:right;">×</a>
  </div>
<?php } ?>
</div>
 <form method='post' name="myForm" enctype="multipart/form-data" action="" id="reg-form" autocomplete="off">
<div class="form_wrapper">
<div class="input_box_wrapper">
                <label>Name</label>
                <div class="input_box"><input type='text' id="name" name='name' class='form-control' placeholder='Name..' value="<?php echo $shop_owner;?>" required/></div>
     </div>
      <div class="input_box_wrapper">
                <label>Email</label>
                <div class="input_box"><input type='text' id="email" name='email' class='form-control' placeholder='Email..' value="<?php echo $shop_email;?>"/></div>
     </div>
 <div class="input_box_wrapper">
                <label>Shop Name</label>
                <div class="input_box"><input type='text' id='shopname' name='shopname' class='form-control' placeholder='EX : https://wwww.demo.com' value="<?php echo $shop_name;?>" /></div>
     </div>

<div class="input_box_wrapper">
                <label>Query</label>
                <div class="input_box"><textarea class="form-control" id="query" name="query" required></textarea></div>
     </div>
<div class="input_box_wrapper" id="ebutton">
             <div class="input_box_submit ebtn"><input type="submit" class="btn_send_email evmbtn" name="btn-save" id="btn_save" value="Submit" />  </div>
        </div>

</div>
</form>

</div>
</div>
</div>

<script>
function clickme()
{
jQuery('.alert-success').hide();
}
setTimeout(function(){
  jQuery('.alert-success').hide();
}, 4000);
</script>
  