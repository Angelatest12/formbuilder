<div class="big-wrapper">
<div class="big-wrapper-container">
<div class="container">
<h3 class="evmheading">Embed Code</h3>
<p>Copy the following embed code and paste it on any page in your online store.</p>
<p>
<textarea readonly=""><div id="evm-form"></div>
<script src="https://formbuilderbyevm.herokuapp.com/embed.js" data-shop-id="<?php echo $shop;?>" data-form-id="<?php echo $form_id;?>" type="text/javascript"></script>
</textarea>
</p>
<span>Need any help? Let us do this for you. <a href="mailto:support@expertvillagemeida.com">Contact Us</a></span>
</div>
</div>
</div>  