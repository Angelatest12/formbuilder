
<?php //print_r($all_forms);?>
<div class="big-wrapper">
<div class="big-wrapper-container">
<div class="container">
        <div id="msg">
           <?php if($this->session->flashdata('message')){?>
          <div class="alert alert-success">      
            <?php echo $this->session->flashdata('message')?><a href="#" class="close" onclick="clickme();" data-dismiss="alert" style="float:right;">×</a>
          </div>
        <?php } ?>
        </div>
        <form class="form-horizontal" id="Formbuilder" action="<?php echo base_url().'Formbuilder/deleteAll'?>" method="post" role="form" data-toggle="validator">
        <div class="evmmaindiv"><div class="left"><h3 class="evmheading">Forms</h3></div><div class="right"><input type="submit" name="submit" class="evmbtn evmbtnsubmit" value="Delete Selected" /> &nbsp;<a href="<?php echo base_url().'Formbuilder/create_form/'.$shop;?>" class="evmbtn">Create New Form</a></div></div>
            <table class="table table-striped" id="example">
            <thead>
                <tr>
                    <th><input type="checkbox" name="chkall" value="all" id="checkedAll"></th>
                    <th>Form Title</th>
                    <th >Created date</th>
                    <th >Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if($all_forms)
            {
                foreach($all_forms as $key=>$val)
                {
                    $id = $val->id;
                    ?>               
                <tr id="ID_<?php echo $val->id;?>">
                <td><input type="checkbox" name="chk[]" value="<?php echo $val->id;?>" class="checkSingle" title="Select all">
                    <input type="hidden" name="shop_name" value="<?php echo $val->shop_name;?>">
                </td>
                <td><?php echo $val->form_title;?></td>
                <td><?php echo $val->create_date;?></td>           
                <td class="action">
                <a href="<?php echo base_url().'Formbuilder/edit_form/'.$shop.'/'.$id;?>" title="Edit Form"><i class="fa fa-edit" aria-hidden="true"></i></a> 
                <a href="<?php echo base_url().'Formbuilder/view_form/'.$shop.'/'.$id;?>" title="View Form" ><i class="fa fa-eye" aria-hidden="true"></i></a>
                <a href="#" onclick="return delete_record('<?php echo base64_encode( $val->id); ?>','<?php echo  $val->id; ?>');" title="Delete Form"><i class="fa fa-trash-o" aria-hidden="true"></i>
                <!-- <a href="<?php echo base_url().'Formbuilder/setting/'.$shop.'/'.$id;?>" title="Setting"><i class="fa fa-cog" aria-hidden="true"></i></a> -->
                <a href="<?php echo base_url().'Formbuilder/embed/'.$shop.'/'.$id;?>"  title="Embed Code"><i class="fa fa-code" aria-hidden="true"></i></a>
                </td>
                </tr> 
            <?php 
                }
                }?>                            
            </tbody>
         </table> 
 
        </form>
    </div>      
</div>   
</div>

<script type="text/javascript">
$(document).ready(function() {
  $("#checkedAll").change(function(){
    if(this.checked){
      $(".checkSingle").each(function(){
        this.checked=true;
      })              
    }else{
      $(".checkSingle").each(function(){
        this.checked=false;
      })              
    }
  });

  $(".checkSingle").click(function () { 
    if ($(this).is(":checked")){
      var isAllChecked = 0;
      $(".checkSingle").each(function(){
        if(!this.checked)
           isAllChecked = 1;
      })              
      if(isAllChecked == 0){ $("#checkedAll").prop("checked", true); }     
    }else {
      $("#checkedAll").prop("checked", false);
    }
  });


$(".evmsubmit").click(function () {
  if($(".checkSingle").is(":checked"))
  {
    if(confirm("Are you sure you want to delete ?"))
      {
        return true;
      }
      else
      {
        return false;
      }    
  }
  else
  {
    alert('Please select atleast one Form.');
    return false;
  }
});


});


function delete_record(ID,id) 
{
      if(confirm("Are you sure you want to delete ?"))
      {
        var shop_name = '<?php echo $shop;?>';
          url = "<?php echo base_url().'Formbuilder/delete'?>";
          jQuery.ajax({
          type:"POST",
          url: url,
          data: {ID:ID,shop_address:shop_name},
          success: function(data)
          {            
              if(data==1)
              {
               jQuery("#ID_"+id).hide();
               jQuery("#msg").html('<div class="alert alert-success" >Form deleted successfully.<a href="#" class="close" onclick="clickme();" data-dismiss="alert" style="float:right;">×</a></div>');
               setTimeout(function(){
                  jQuery('.alert-success').hide();
                }, 4000);
              }                         
          }
        });
      }
}   
function clickme()
{
jQuery('.alert-success').hide();
}
setTimeout(function(){
  jQuery('.alert-success').hide();
}, 4000);
</script>
<script src="https://cdn.shopify.com/s/assets/external/app.js"></script>

