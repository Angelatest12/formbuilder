<script type="text/javascript">
//On document ready
$(function(){
    //load saved form by ID
    var formID = '<?php echo $id;?>';
    generateForm(formID);
   
});
</script>
<div class="big-wrapper">
<div class="big-wrapper-container">
<div class="container">
<div id="sjfb-wrap" class="evmformview">
<div class="add-wraptitle">
    <h3><?php echo $form_title;?></h3>
        
    <input type="hidden" name="shop_name" id="shop_name" value="<?php echo $shop;?>">
</div>
    <form id="sjfb-sample">
        <div id="sjfb-fields">
        </div>
        <button type="button" disabled="disabled" class="submit btn" name="submit">Submit</button>      
    </form>
</div>
</div>
</div>
</div>

