<?php 
//echo "<pre>";
//print_r(json_decode($form_fields));
$form_data = json_decode($form_fields);
?>
<div class="big-wrapper">
<div class="big-wrapper-container">
<div class="container">
<div id="sjfb-wrap">  
 <div class="add-wrap evmformleft">
                <h3>Form Title:</h3>
                <input type="text" name="form_title" id="form_title" value="<?php echo $form_title;?>">
                <input type="hidden" name="shop_name" id="shop_name" value="<?php echo $shop;?>">
                <form id="sjfb" novalidate>
<input type="hidden" name="form_id" id="form_id" value="<?php echo $form_id;?>">
<div id="form-fields" class="ui-sortable">
<?php
$i=0;
foreach($form_data as $key=>$val)
{
$i++;
$newclass = "";
if($i==1)
{
   $newclass = "ui-sortable-handle";
}
    if($val->type == 'select' || $val->type=='radio' || $val->type=='checkbox')
    {
        ?>
        <div class="field <?php if(!empty($newclass))echo $newclass;?> <?php if($val->req==1){echo "required";}?>" data-type="<?php echo $val->type;?>" style="display: block;"><button type="button" class="delete btn"><i class="fa fa-trash-o" aria-hidden="true"></i></button><h3><?php  echo ucfirst($val->type);?></h3><div class="evmlabel"><label>Label:<input type="text" class="field-label" value="<?php echo $val->label;?>"></label><label>Required? <input class="toggle-required"  <?php  if($val->req==1){echo 'checked="checked"';}?>  type="checkbox"></label></div>

        <div class="choices"><ul class="ui-sortable">
        <?php if(!empty($val->choices) && is_array($val->choices))
        {
            if($val->choices)
            {
            foreach($val->choices as $ckey=>$cval)
            {
            ?>
        <li class="ui-sortable-handle <?php  if($cval->sel==1){echo 'selected';}?>" style="display: list-item;"><label><span>Option:</span> <input type="text" class="choice-label" value="<?php echo $cval->label;?>"></label><label>Selected? <input class="toggle-selected" type="checkbox" <?php  if($cval->sel==1){echo 'checked="checked"';}?> ></label><button type="button" class="delete btn"><i class="fa fa-trash-o" aria-hidden="true"></i></button></li>
        <?php
            }
            }
        }
        ?>
        </ul><button type="button" class="add-choice btn">+ Add Choice</button></div></div>
        <?php
    }
    else if($val->type == 'agree')
    {
    ?>
<div class="field <?php if(!empty($newclass)) echo $newclass;?>" data-type="<?php echo $val->type;?>" style="display: block;"><button type="button" class="delete btn"><i class="fa fa-trash-o" aria-hidden="true"></i></button><h3><?php  echo ucfirst($val->type);?></h3><label>Label:<input type="text" class="field-label" value="<?php echo $val->label;?>"></label></div> 
    <?php 
    }
    else
    {
    ?>
<div class="field <?php if(!empty($newclass)) echo $newclass;?> <?php if($val->req==1){echo "required";}?>" data-type="<?php echo $val->type;?>" style="display: block;"><button type="button" class="delete btn"><i class="fa fa-trash-o" aria-hidden="true"></i></button><h3><?php  echo ucfirst($val->type);?></h3><div class="evmlabel"><label>Label:<input type="text" class="field-label" value="<?php echo $val->label;?>"></label><label>Required? <input class="toggle-required" <?php  if($val->req==1){echo 'checked="checked"';}?> type="checkbox"></label></div> </div> 
    <?php 
    }
}
?>
</div>
<button type="submit" class="submit btn">Save Form</button>
</form>
            </div>
 <div class="add-wrap evmformright">
                <h3>Clcik below to add Field(s):</h3>
                <ul id="add-field">
                    <li><a id="add-text" data-type="text" href="#">Single Line Text</a></li>
                    <li><a id="add-email" data-type="email" href="#">Email</a></li>
                    <li><a id="add-textarea" data-type="textarea" href="#">Textarea</a></li>
                    <li><a id="add-select" data-type="select" href="#">Select Box </a></li>
                    <li><a id="add-radio" data-type="radio" href="#">Radio Buttons</a></li>
                    <li><a id="add-checkbox" data-type="checkbox" href="#">Checkboxes</a></li>
                    <!-- <li><a id="add-agree" data-type="agree" href="#">Agree Box</a></li> -->
                </ul>
            </div>

</div>
</div>
</div>
</div>

<script>
    

    $("#sjfb").submit(function(event) {
        event.preventDefault();

        //Loop through fields and save field data to array
        var fields = [];

        $('.field').each(function() {

            var $this = $(this);

            //field type
            var fieldType = $this.data('type');

            //field label
            var fieldLabel = $this.find('.field-label').val();

            //field required
            var fieldReq = $this.hasClass('required') ? 1 : 0;

            //check if this field has choices
            if($this.find('.choices li').length >= 1) {

                var choices = [];

                $this.find('.choices li').each(function() {

                    var $thisChoice = $(this);

                    //choice label
                    var choiceLabel = $thisChoice.find('.choice-label').val();

                    //choice selected
                    var choiceSel = $thisChoice.hasClass('selected') ? 1 : 0;

                    choices.push({
                        label: choiceLabel,
                        sel: choiceSel
                    });
                });
            }
            fields.push({
                type: fieldType,
                label: fieldLabel,
                req: fieldReq,
                choices: choices
            });
        });
       var  form_title = jQuery('#form_title').val();
       var  shop_name = jQuery('#shop_name').val();
       var  form_id = jQuery('#form_id').val();
       var frontEndFormHTML = '';

        //Save form to database
        //Demo doesn't actually save. Download project files for save
        var data = JSON.stringify([{"name":"form_id","value":form_id},{"name":"shop_name","value":shop_name},{"name":"form_title","value":form_title},{"name":"formFields","value":fields}]);
        console.log(data);
        

        $.ajax({
            method: "POST",
            url: "https://formbuilderbyevm.herokuapp.com/Formbuilder/form_save",
            data: data,
            dataType: 'json',
            success: function (responce) {
                console.log(responce['id']);
                console.log(responce['shop']);
                //alert(msg);
                //if(responce!='error')
               // {
                    
                    var shop = responce.shop;
                    var id = responce.id;
                   
                   // $('.alert').removeClass('hide');
                   // $("html, body").animate({ scrollTop: 0 }, "fast");           

                    window.location.href="https://formbuilderbyevm.herokuapp.com/Formbuilder?shop="+shop+"";
                //}
                //else
               // {

               // }                
            }
        });   
    });
</script>