<div class="footerwrapper">
<div class="footer_container">
<h2>Recommended shopify apps!</h2>
<div class="footer_block"><a href="https://apps.shopify.com/shop-by-instagram" target="_blank"><img src="<?php echo base_url();?>/images/shop-by-insta.jpg" /></a></div>
<div class="footer_block"><a href="https://apps.shopify.com/evm-lookbook" target="_blank"><img src="<?php echo base_url();?>/images/lookbook.jpg" /></a></div>
<div class="footer_block"><a href="https://apps.shopify.com/evm-testimonials-showcase" target="_blank"><img src="<?php echo base_url();?>/images/testimonial.jpg" /></a></div>
<div class="footer_block"><a href="https://apps.shopify.com/evm-video-gallery" target="_blank"><img src="<?php echo base_url();?>/images/video.jpg" /></a></div>
<div class="footer_block"><a href="https://apps.shopify.com/instagram-feed" target="_blank"><img src="<?php echo base_url();?>/images/instagram.jpg" /></a></div>
<div class="footer_block"><a href="https://apps.shopify.com/your-recently-viewed-products" target="_blank"><img src="<?php echo base_url();?>/images/rvp.jpg" /></a></div>
</div>
</div>
</body>
</html>
<script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
  <script type="text/javascript">
   ShopifyApp.init({  
     apiKey: '457d2c4a39f66947710e41b1c88ebebd',
     shopOrigin: 'https://<?php echo $shop;?>'
   });
  ShopifyApp.ready(function(){
    ShopifyApp.Bar.initialize({
      title: '<?php echo $title;?>'
    });
    ShopifyApp.Bar.loadingOff(); 
  });
</script>