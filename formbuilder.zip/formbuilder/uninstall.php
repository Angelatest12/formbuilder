<?php
$dsn = "pgsql:"
    . "host=ec2-107-21-99-176.compute-1.amazonaws.com;"
    . "dbname=da1p7b2mu66n1u;"
    . "user=cahxrzwkkycdoo;"
    . "port=5432;"
    . "password=b6e4c7bc1ce38aeb38c0146a59c01607f770bd887a7da1c5babe3d493c89c905";
	$db = new PDO($dsn);
	$query_params['shop'] = $_GET['shop'];
	$select_store_data=$db->query("SELECT * FROM app_data_tbl WHERE shop_address = '".$query_params['shop']."'");
    $shop_data=$select_store_data->fetchALL(PDO::FETCH_ASSOC);
    $shop_details = $shop_data[0];
    
    $shop_name=$shop_details['shop_address'];
    $shop_token=$shop_details['shop_token'];
    $shop_email=$shop_details['shop_email'];
    
    if($shop_details)
    {        
        $delete_store_data = $db->query("DELETE FROM app_data_tbl WHERE shop_address = '".$query_params['shop']."'");
       	

$to = $shop_email; // this is your Email address
//$to = "vinita@expertvillagemedia.com";
							$from = "support@expertvillagemedia.com"; // this is the sender's Email address
							$subject = "If you experienced any issues with our Formbuilder app please let us know";
							$message = "<p>Hello,</p>

							<p>We're sorry to see you go.</p>

							<p>If you've experienced any issues with our app, please let us know and We will contact you right away with a fix to the issue. If there is also any feature that you would have loved to see in our app just let us know and we will do our best to integrate it.</p>

							<p>Hope to hear from you!</p>

							<p>Kind regards,</p>
							<p>Expert Village Media</p>";

							$url = 'https://api.sendgrid.com/';
							$user = 'app65982267@heroku.com';
							$pass = 'test111G';
							$params = array( 
							      'api_user' => $user,
							      'api_key' => $pass,
							      'to' => $to,
							      'subject' => $subject,
							      'html' => $message,
							      'text' => $message,
							      'from' => $from,
							   );
							 $request = $url.'api/mail.send.json';
							 $session = curl_init($request);
							 curl_setopt ($session, CURLOPT_POST, true);
							 curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
							 curl_setopt($session, CURLOPT_HEADER, false);
							 curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
							 $response = curl_exec($session);
							 //print_r($response);
							 curl_close($session);
							 die;
	}

?>